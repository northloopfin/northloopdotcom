import { combineReducers } from 'redux'
import home from './modules/home'

export default combineReducers({
  home,
})
