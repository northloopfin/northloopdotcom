## Convention

The following will be convention for this api/

* You can only put your api request here, no business logic.
* You should separate your api files by "requested resources"
* Your api should return a "Promise" interface for consistency
* And you use `index.js` to expose your api

This folder will contain an example using axios, it is not a working api, but show case how you should structure your apis.
