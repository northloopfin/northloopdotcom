/*
// This is an home will not work
// Just only show case how I would orangize
const API_ENDPOINT = __CONFIG__.apiUrl.avengers

export const getTopTenAvengers = (query = {}) => {
  return axios.get(`${API_ENDPOINT}?count=10`)
}
*/
