export type homeType = {
  title: string,
  description: string,
  source: string
};
